import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import { db } from "./src/firebase.ts"; // Note: This might need adjustment if server runs in node
import { 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  setDoc, 
  updateDoc, 
  addDoc, 
  query, 
  where, 
  orderBy, 
  limit, 
  serverTimestamp,
  runTransaction,
  Timestamp
} from "firebase/firestore";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  
  // 1. Execute Trade
  app.post("/api/trade", async (req, res) => {
    const { userId, marketId, side, amount } = req.body;

    if (!userId || !marketId || !side || !amount || amount <= 0) {
      return res.status(400).json({ error: "Invalid trade parameters" });
    }

    try {
      const result = await runTransaction(db, async (transaction) => {
        const userRef = doc(db, "users", userId);
        const marketRef = doc(db, "markets", marketId);
        const positionId = `${userId}_${marketId}`;
        const positionRef = doc(db, "positions", positionId);

        const userDoc = await transaction.get(userRef);
        const marketDoc = await transaction.get(marketRef);

        if (!userDoc.exists()) throw "User not found";
        if (!marketDoc.exists()) throw "Market not found";

        const userData = userDoc.data();
        const marketData = marketDoc.data();

        if (marketData.status !== 'active') throw "Market is not active";
        if (userData.cashBalance < amount) throw "Insufficient balance";

        // Simple CPMM-like pricing engine
        // P = y / (y + n)
        // For MVP, we'll use a simplified model where price moves based on trade size relative to liquidity
        const currentPrice = side === 'YES' ? marketData.yesPrice : marketData.noPrice;
        const slippage = amount / (marketData.liquidity * 10); // Simple slippage model
        const avgPrice = Math.min(0.99, currentPrice + slippage / 2);
        const shares = amount / avgPrice;

        // Update User Balance
        const newBalance = userData.cashBalance - amount;
        transaction.update(userRef, { 
          cashBalance: newBalance,
          updatedAt: new Date().toISOString()
        });

        // Update Market Pricing & Volume
        const newYesPrice = side === 'YES' 
          ? Math.min(0.99, marketData.yesPrice + slippage)
          : Math.max(0.01, marketData.yesPrice - slippage);
        const newNoPrice = 1 - newYesPrice;

        transaction.update(marketRef, {
          yesPrice: newYesPrice,
          noPrice: newNoPrice,
          volume: marketData.volume + amount,
          updatedAt: new Date().toISOString()
        });

        // Update Position
        let positionData = {
          userId,
          marketId,
          yesShares: 0,
          noShares: 0,
          avgYesEntry: 0,
          avgNoEntry: 0,
          realizedPnL: 0,
          updatedAt: new Date().toISOString()
        };

        const posDoc = await transaction.get(positionRef);
        if (posDoc.exists()) {
          positionData = posDoc.data() as any;
        }

        if (side === 'YES') {
          const totalCost = (positionData.yesShares * positionData.avgYesEntry) + amount;
          positionData.yesShares += shares;
          positionData.avgYesEntry = totalCost / positionData.yesShares;
        } else {
          const totalCost = (positionData.noShares * positionData.avgNoEntry) + amount;
          positionData.noShares += shares;
          positionData.avgNoEntry = totalCost / positionData.noShares;
        }
        positionData.updatedAt = new Date().toISOString();
        transaction.set(positionRef, positionData);

        // Record Trade
        const tradeRef = doc(collection(db, "trades"));
        transaction.set(tradeRef, {
          userId,
          marketId,
          side,
          action: 'BUY',
          shares,
          pricePerShare: avgPrice,
          totalCost: amount,
          createdAt: new Date().toISOString()
        });

        // Record Transaction
        const transRef = doc(collection(db, "transactions"));
        transaction.set(transRef, {
          userId,
          type: 'trade',
          amount: -amount,
          balanceBefore: userData.cashBalance,
          balanceAfter: newBalance,
          referenceId: tradeRef.id,
          createdAt: new Date().toISOString()
        });

        // Record Price History
        const historyRef = doc(collection(db, "priceHistory"));
        transaction.set(historyRef, {
          marketId,
          timestamp: new Date().toISOString(),
          yesPrice: newYesPrice,
          noPrice: newNoPrice,
          volumeSnapshot: marketData.volume + amount
        });

        return { shares, avgPrice, newBalance };
      });

      res.json(result);
    } catch (error: any) {
      console.error("Trade Error:", error);
      res.status(500).json({ error: error.toString() });
    }
  });

  // 2. Resolve Market (Admin Only)
  app.post("/api/admin/resolve", async (req, res) => {
    const { marketId, outcome, adminId } = req.body;

    try {
      const adminDoc = await getDoc(doc(db, "users", adminId));
      if (!adminDoc.exists() || adminDoc.data().role !== 'admin') {
        return res.status(403).json({ error: "Unauthorized" });
      }

      await runTransaction(db, async (transaction) => {
        const marketRef = doc(db, "markets", marketId);
        const marketDoc = await transaction.get(marketRef);
        if (!marketDoc.exists()) throw "Market not found";
        const marketData = marketDoc.data();
        if (marketData.status !== 'active') throw "Market not active";

        // Update Market Status
        transaction.update(marketRef, {
          status: 'resolved',
          resolvedOutcome: outcome,
          updatedAt: new Date().toISOString()
        });

        // Settle all positions
        const positionsQuery = query(collection(db, "positions"), where("marketId", "==", marketId));
        const positionsSnap = await getDocs(positionsQuery);

        for (const posDoc of positionsSnap.docs) {
          const posData = posDoc.data();
          const userRef = doc(db, "users", posData.userId);
          const userDoc = await transaction.get(userRef);
          if (!userDoc.exists()) continue;

          const winningShares = outcome === 'YES' ? posData.yesShares : posData.noShares;
          const payout = winningShares * 1; // Each winning share settles to $1

          if (payout > 0) {
            const userData = userDoc.data();
            const newBalance = userData.cashBalance + payout;
            transaction.update(userRef, {
              cashBalance: newBalance,
              updatedAt: new Date().toISOString()
            });

            // Record Transaction
            const transRef = doc(collection(db, "transactions"));
            transaction.set(transRef, {
              userId: posData.userId,
              type: 'settlement',
              amount: payout,
              balanceBefore: userData.cashBalance,
              balanceAfter: newBalance,
              referenceId: marketId,
              createdAt: new Date().toISOString()
            });
          }
        }
      });

      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.toString() });
    }
  });

  // 3. Seed Data (Admin Only)
  app.post("/api/admin/seed", async (req, res) => {
    const { adminId } = req.body;
    try {
      const adminDoc = await getDoc(doc(db, "users", adminId));
      if (!adminDoc.exists() || adminDoc.data().role !== 'admin') {
        return res.status(403).json({ error: "Unauthorized" });
      }

      const categories = [
        { name: "Crypto", slug: "crypto", description: "Cryptocurrency markets" },
        { name: "Tech", slug: "tech", description: "Technology and AI" },
        { name: "Sports", slug: "sports", description: "Sports events" },
        { name: "Politics", slug: "politics", description: "Political outcomes" }
      ];

      for (const cat of categories) {
        await setDoc(doc(db, "categories", cat.slug), cat);
      }

      const markets = [
        {
          slug: "btc-120k-2026",
          title: "Will Bitcoin close above $120k by Dec 31, 2026?",
          summary: "Bitcoin price prediction for end of 2026.",
          description: "This market resolves to YES if the Bitcoin price is above $120,000 at 11:59 PM UTC on Dec 31, 2026.",
          categoryId: "crypto",
          rules: "Price source: CoinGecko or Binance.",
          resolutionSource: "CoinGecko",
          status: "active",
          endDate: "2026-12-31T23:59:59Z",
          closeDate: "2026-12-31T23:59:59Z",
          yesPrice: 0.65,
          noPrice: 0.35,
          volume: 12500,
          liquidity: 5000,
          createdBy: adminId,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        },
        {
          slug: "gpt-6-2027",
          title: "Will OpenAI release GPT-6 before Jan 1, 2027?",
          summary: "AI model release prediction.",
          description: "Resolves to YES if OpenAI officially announces and releases GPT-6 to any user group before 2027.",
          categoryId: "tech",
          rules: "Official OpenAI announcement required.",
          resolutionSource: "OpenAI Blog",
          status: "active",
          endDate: "2027-01-01T00:00:00Z",
          closeDate: "2027-01-01T00:00:00Z",
          yesPrice: 0.42,
          noPrice: 0.58,
          volume: 8400,
          liquidity: 3000,
          createdBy: adminId,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        }
      ];

      for (const m of markets) {
        await setDoc(doc(db, "markets", m.slug), m);
      }

      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.toString() });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
