import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { 
  TrendingUp, 
  LayoutDashboard, 
  User as UserIcon, 
  LogOut, 
  LogIn,
  ShieldCheck,
  Trophy
} from 'lucide-react';
import { cn, formatCurrency } from '../lib/utils';

export const Navbar: React.FC = () => {
  const { user, login, logout } = useAuth();
  const location = useLocation();

  const navItems = [
    { label: 'Markets', path: '/markets', icon: TrendingUp },
    { label: 'Portfolio', path: '/portfolio', icon: LayoutDashboard, protected: true },
    { label: 'Leaderboard', path: '/leaderboard', icon: Trophy },
  ];

  return (
    <nav className="sticky top-0 z-50 w-full border-b border-white/10 bg-black/80 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-8">
          <Link to="/" className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-orange-500 font-bold text-black">
              F
            </div>
            <span className="text-xl font-bold tracking-tight text-white">ForecastX</span>
          </Link>

          <div className="hidden items-center gap-1 md:flex">
            {navItems.map((item) => (
              (!item.protected || user) && (
                <Link
                  key={item.path}
                  to={item.path}
                  className={cn(
                    "flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium transition-colors hover:bg-white/5",
                    location.pathname === item.path ? "text-orange-500" : "text-zinc-400 hover:text-white"
                  )}
                >
                  <item.icon className="h-4 w-4" />
                  {item.label}
                </Link>
              )
            ))}
          </div>
        </div>

        <div className="flex items-center gap-4">
          {user ? (
            <div className="flex items-center gap-4">
              <div className="hidden flex-col items-end sm:flex">
                <span className="text-xs text-zinc-500">Balance</span>
                <span className="font-mono text-sm font-bold text-green-400">
                  {formatCurrency(user.cashBalance)}
                </span>
              </div>
              
              {user.role === 'admin' && (
                <Link 
                  to="/admin" 
                  className="rounded-full bg-zinc-800 p-2 text-zinc-400 hover:bg-zinc-700 hover:text-white transition-colors"
                  title="Admin Dashboard"
                >
                  <ShieldCheck className="h-5 w-5" />
                </Link>
              )}

              <div className="group relative">
                <button className="flex h-9 w-9 items-center justify-center rounded-full border border-white/10 bg-zinc-900 transition-colors hover:border-orange-500/50">
                  {user.avatar ? (
                    <img src={user.avatar} alt={user.username} className="h-full w-full rounded-full object-cover" referrerPolicy="no-referrer" />
                  ) : (
                    <UserIcon className="h-5 w-5 text-zinc-400" />
                  )}
                </button>
                
                <div className="absolute right-0 top-full mt-2 w-48 origin-top-right scale-95 opacity-0 transition-all group-hover:scale-100 group-hover:opacity-100">
                  <div className="rounded-lg border border-white/10 bg-zinc-900 p-1 shadow-xl">
                    <div className="px-3 py-2 text-xs text-zinc-500">
                      Signed in as <span className="text-zinc-200">{user.username}</span>
                    </div>
                    <div className="h-px bg-white/5" />
                    <button
                      onClick={() => logout()}
                      className="flex w-full items-center gap-2 rounded-md px-3 py-2 text-left text-sm text-red-400 transition-colors hover:bg-red-500/10"
                    >
                      <LogOut className="h-4 w-4" />
                      Sign Out
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <button
              onClick={() => login()}
              className="flex items-center gap-2 rounded-full bg-orange-500 px-5 py-2 text-sm font-bold text-black transition-transform hover:scale-105 active:scale-95"
            >
              <LogIn className="h-4 w-4" />
              Sign In
            </button>
          )}
        </div>
      </div>
    </nav>
  );
};
