import React from 'react';
import { Link } from 'react-router-dom';
import { Market } from '../types';
import { formatCurrency, formatProbability } from '../lib/utils';
import { motion } from 'motion/react';
import { Clock, TrendingUp, Users } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

interface MarketCardProps {
  market: Market;
}

export const MarketCard: React.FC<MarketCardProps> = ({ market }) => {
  const isEndingSoon = new Date(market.endDate).getTime() - Date.now() < 24 * 60 * 60 * 1000;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4 }}
      className="group relative flex flex-col overflow-hidden rounded-2xl border border-white/10 bg-zinc-900/50 transition-all hover:border-orange-500/30 hover:bg-zinc-900"
    >
      <Link to={`/markets/${market.slug}`} className="absolute inset-0 z-10" />
      
      <div className="relative aspect-video w-full overflow-hidden">
        {market.image ? (
          <img src={market.image} alt={market.title} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110" referrerPolicy="no-referrer" />
        ) : (
          <div className="flex h-full w-full items-center justify-center bg-zinc-800">
            <TrendingUp className="h-12 w-12 text-zinc-700" />
          </div>
        )}
        <div className="absolute left-3 top-3 rounded-full bg-black/60 px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-zinc-300 backdrop-blur-md">
          {market.categoryId}
        </div>
      </div>

      <div className="flex flex-1 flex-col p-5">
        <h3 className="mb-2 line-clamp-2 text-lg font-bold leading-tight text-white group-hover:text-orange-500 transition-colors">
          {market.title}
        </h3>
        <p className="mb-4 line-clamp-2 text-sm text-zinc-400">
          {market.summary}
        </p>

        <div className="mt-auto space-y-4">
          <div className="flex items-center justify-between text-xs text-zinc-500">
            <div className="flex items-center gap-1.5">
              <Clock className={cn("h-3.5 w-3.5", isEndingSoon ? "text-orange-500" : "text-zinc-500")} />
              <span className={isEndingSoon ? "text-orange-500 font-medium" : ""}>
                {formatDistanceToNow(new Date(market.endDate))} left
              </span>
            </div>
            <div className="flex items-center gap-1.5">
              <Users className="h-3.5 w-3.5" />
              <span>{formatCurrency(market.volume)} Vol</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div className="flex flex-col rounded-lg bg-green-500/10 p-2 text-center border border-green-500/20">
              <span className="text-[10px] font-bold uppercase text-green-500">Yes</span>
              <span className="text-lg font-mono font-bold text-green-400">{formatProbability(market.yesPrice)}</span>
            </div>
            <div className="flex flex-col rounded-lg bg-red-500/10 p-2 text-center border border-red-500/20">
              <span className="text-[10px] font-bold uppercase text-red-500">No</span>
              <span className="text-lg font-mono font-bold text-red-400">{formatProbability(market.noPrice)}</span>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

import { cn } from '../lib/utils';
