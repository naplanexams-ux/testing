import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { collection, query, where, limit, getDocs, orderBy } from 'firebase/firestore';
import { db } from '../firebase';
import { Market } from '../types';
import { MarketCard } from '../components/MarketCard';
import { motion } from 'motion/react';
import { ArrowRight, TrendingUp, Shield, Zap } from 'lucide-react';

const LandingPage: React.FC = () => {
  const [featuredMarkets, setFeaturedMarkets] = useState<Market[]>([]);

  useEffect(() => {
    const fetchMarkets = async () => {
      const q = query(
        collection(db, 'markets'),
        where('status', '==', 'active'),
        orderBy('volume', 'desc'),
        limit(3)
      );
      const snap = await getDocs(q);
      setFeaturedMarkets(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Market)));
    };
    fetchMarkets();
  }, []);

  return (
    <div className="space-y-24 pb-20">
      {/* Hero Section */}
      <section className="relative flex flex-col items-center justify-center py-20 text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="absolute -top-20 -z-10 h-[500px] w-[500px] rounded-full bg-orange-500/10 blur-[120px]"
        />
        
        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-4xl text-5xl font-black tracking-tight text-white sm:text-7xl"
        >
          Predict the Future. <br />
          <span className="text-orange-500">Trade the Outcome.</span>
        </motion.h1>
        
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mt-6 max-w-2xl text-lg text-zinc-400"
        >
          ForecastX is the premier binary prediction market platform. 
          Use virtual money to trade on world events, tech breakthroughs, and market trends.
        </motion.p>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mt-10 flex flex-wrap justify-center gap-4"
        >
          <Link 
            to="/markets" 
            className="flex items-center gap-2 rounded-full bg-orange-500 px-8 py-4 text-lg font-bold text-black transition-transform hover:scale-105 active:scale-95"
          >
            Explore Markets
            <ArrowRight className="h-5 w-5" />
          </Link>
          <Link 
            to="/leaderboard" 
            className="flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-8 py-4 text-lg font-bold text-white transition-colors hover:bg-white/10"
          >
            View Leaderboard
          </Link>
        </motion.div>
      </section>

      {/* Featured Markets */}
      <section className="space-y-8">
        <div className="flex items-end justify-between">
          <div>
            <h2 className="text-3xl font-bold text-white">Trending Markets</h2>
            <p className="text-zinc-500">Most active markets right now</p>
          </div>
          <Link to="/markets" className="text-sm font-bold text-orange-500 hover:underline">
            View all markets
          </Link>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {featuredMarkets.map((market) => (
            <MarketCard key={market.id} market={market} />
          ))}
          {featuredMarkets.length === 0 && (
             [1,2,3].map(i => (
               <div key={i} className="h-[400px] animate-pulse rounded-2xl bg-zinc-900/50" />
             ))
          )}
        </div>
      </section>

      {/* How it Works */}
      <section className="grid gap-12 lg:grid-cols-3">
        <div className="flex flex-col items-center text-center space-y-4 p-8 rounded-3xl bg-zinc-900/30 border border-white/5">
          <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-orange-500/10 text-orange-500">
            <Zap className="h-8 w-8" />
          </div>
          <h3 className="text-xl font-bold text-white">Pick a Market</h3>
          <p className="text-zinc-500 text-sm">Browse hundreds of markets across crypto, tech, sports, and politics.</p>
        </div>
        <div className="flex flex-col items-center text-center space-y-4 p-8 rounded-3xl bg-zinc-900/30 border border-white/5">
          <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-blue-500/10 text-blue-500">
            <TrendingUp className="h-8 w-8" />
          </div>
          <h3 className="text-xl font-bold text-white">Trade Shares</h3>
          <p className="text-zinc-500 text-sm">Buy YES or NO shares based on your prediction. Prices reflect probability.</p>
        </div>
        <div className="flex flex-col items-center text-center space-y-4 p-8 rounded-3xl bg-zinc-900/30 border border-white/5">
          <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-green-500/10 text-green-500">
            <Shield className="h-8 w-8" />
          </div>
          <h3 className="text-xl font-bold text-white">Win Demo Cash</h3>
          <p className="text-zinc-500 text-sm">If you're right, your shares settle to $1.00 each. Build your virtual portfolio.</p>
        </div>
      </section>
    </div>
  );
};

export default LandingPage;
