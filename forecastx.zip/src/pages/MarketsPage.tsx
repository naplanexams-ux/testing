import React, { useEffect, useState } from 'react';
import { collection, query, where, getDocs, orderBy } from 'firebase/firestore';
import { db } from '../firebase';
import { Market, Category } from '../types';
import { MarketCard } from '../components/MarketCard';
import { Search, Filter, SlidersHorizontal } from 'lucide-react';
import { cn } from '../lib/utils';

const MarketsPage: React.FC = () => {
  const [markets, setMarkets] = useState<Market[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState<'volume' | 'newest' | 'ending'>('volume');

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const catSnap = await getDocs(collection(db, 'categories'));
        setCategories(catSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Category)));

        let q = query(collection(db, 'markets'), where('status', '==', 'active'));
        
        if (sortBy === 'volume') q = query(q, orderBy('volume', 'desc'));
        if (sortBy === 'newest') q = query(q, orderBy('createdAt', 'desc'));
        if (sortBy === 'ending') q = query(q, orderBy('endDate', 'asc'));

        const marketSnap = await getDocs(q);
        setMarkets(marketSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Market)));
      } catch (error) {
        console.error("Error fetching markets:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [sortBy]);

  const filteredMarkets = markets.filter(m => {
    const matchesSearch = m.title.toLowerCase().includes(search.toLowerCase()) || 
                          m.summary.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = !selectedCategory || m.categoryId === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="space-y-8">
      <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-4xl font-black text-white">Markets</h1>
          <p className="text-zinc-500">Discover and trade on future outcomes</p>
        </div>

        <div className="relative w-full max-w-md">
          <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-zinc-500" />
          <input
            type="text"
            placeholder="Search markets..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full rounded-xl border border-white/10 bg-zinc-900 py-3 pl-10 pr-4 text-sm text-white focus:border-orange-500/50 focus:outline-none transition-colors"
          />
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-4">
        <div className="flex items-center gap-2 overflow-x-auto pb-2 sm:pb-0 no-scrollbar">
          <button
            onClick={() => setSelectedCategory(null)}
            className={cn(
              "whitespace-nowrap rounded-full px-4 py-1.5 text-sm font-medium transition-colors",
              !selectedCategory ? "bg-orange-500 text-black" : "bg-zinc-900 text-zinc-400 hover:text-white"
            )}
          >
            All
          </button>
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.slug)}
              className={cn(
                "whitespace-nowrap rounded-full px-4 py-1.5 text-sm font-medium transition-colors",
                selectedCategory === cat.slug ? "bg-orange-500 text-black" : "bg-zinc-900 text-zinc-400 hover:text-white"
              )}
            >
              {cat.name}
            </button>
          ))}
        </div>

        <div className="ml-auto flex items-center gap-2">
          <SlidersHorizontal className="h-4 w-4 text-zinc-500" />
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="rounded-lg border border-white/10 bg-zinc-900 px-3 py-1.5 text-xs font-medium text-zinc-300 focus:outline-none"
          >
            <option value="volume">Highest Volume</option>
            <option value="newest">Newest</option>
            <option value="ending">Ending Soon</option>
          </select>
        </div>
      </div>

      {loading ? (
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {[1,2,3,4,5,6].map(i => (
            <div key={i} className="h-[400px] animate-pulse rounded-2xl bg-zinc-900/50" />
          ))}
        </div>
      ) : filteredMarkets.length > 0 ? (
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {filteredMarkets.map((market) => (
            <MarketCard key={market.id} market={market} />
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <div className="rounded-full bg-zinc-900 p-6">
            <Filter className="h-10 w-10 text-zinc-700" />
          </div>
          <h3 className="mt-4 text-xl font-bold text-white">No markets found</h3>
          <p className="text-zinc-500">Try adjusting your filters or search terms</p>
        </div>
      )}
    </div>
  );
};

export default MarketsPage;
