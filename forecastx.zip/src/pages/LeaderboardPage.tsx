import React, { useEffect, useState } from 'react';
import { collection, query, orderBy, limit, getDocs } from 'firebase/firestore';
import { db } from '../firebase';
import { User } from '../types';
import { Trophy, Medal, TrendingUp, Users } from 'lucide-react';
import { formatCurrency, cn } from '../lib/utils';
import { motion } from 'motion/react';

const LeaderboardPage: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchLeaderboard = async () => {
      const q = query(collection(db, 'users'), orderBy('cashBalance', 'desc'), limit(50));
      const snap = await getDocs(q);
      setUsers(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as User)));
      setLoading(false);
    };
    fetchLeaderboard();
  }, []);

  return (
    <div className="space-y-10 pb-20">
      <header className="text-center space-y-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="mx-auto flex h-20 w-20 items-center justify-center rounded-3xl bg-orange-500/10 text-orange-500"
        >
          <Trophy className="h-10 w-10" />
        </motion.div>
        <h1 className="text-4xl font-black text-white">Leaderboard</h1>
        <p className="text-zinc-500">Top traders by virtual portfolio value</p>
      </header>

      <div className="mx-auto max-w-3xl overflow-hidden rounded-3xl border border-white/10 bg-zinc-900/30">
        <table className="w-full text-left">
          <thead className="border-b border-white/5 bg-white/5 text-xs font-bold uppercase text-zinc-500">
            <tr>
              <th className="px-8 py-5">Rank</th>
              <th className="px-8 py-5">Trader</th>
              <th className="px-8 py-5 text-right">Portfolio Value</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {users.map((trader, index) => (
              <tr key={trader.id} className="group hover:bg-white/5 transition-colors">
                <td className="px-8 py-5">
                  <div className="flex items-center gap-3">
                    <span className={cn(
                      "flex h-8 w-8 items-center justify-center rounded-lg font-bold",
                      index === 0 ? "bg-yellow-500 text-black" :
                      index === 1 ? "bg-zinc-300 text-black" :
                      index === 2 ? "bg-orange-600 text-white" :
                      "bg-zinc-800 text-zinc-500"
                    )}>
                      {index + 1}
                    </span>
                    {index < 3 && <Medal className={cn(
                      "h-4 w-4",
                      index === 0 ? "text-yellow-500" :
                      index === 1 ? "text-zinc-300" :
                      "text-orange-600"
                    )} />}
                  </div>
                </td>
                <td className="px-8 py-5">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 overflow-hidden rounded-full bg-zinc-800">
                      {trader.avatar ? (
                        <img src={trader.avatar} alt={trader.username} className="h-full w-full object-cover" referrerPolicy="no-referrer" />
                      ) : (
                        <div className="flex h-full w-full items-center justify-center text-zinc-600 font-bold">
                          {trader.username[0].toUpperCase()}
                        </div>
                      )}
                    </div>
                    <span className="font-bold text-white group-hover:text-orange-500 transition-colors">
                      {trader.username}
                    </span>
                  </div>
                </td>
                <td className="px-8 py-5 text-right">
                  <span className="font-mono text-lg font-black text-green-400">
                    {formatCurrency(trader.cashBalance)}
                  </span>
                </td>
              </tr>
            ))}
            {loading && (
              [1,2,3,4,5].map(i => (
                <tr key={i} className="animate-pulse">
                  <td colSpan={3} className="px-8 py-8">
                    <div className="h-8 w-full rounded-lg bg-zinc-800/50" />
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default LeaderboardPage;
