import React, { useState, useEffect } from 'react';
import { collection, addDoc, getDocs, query, orderBy, setDoc, doc, updateDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../context/AuthContext';
import { Market, Category } from '../types';
import { Plus, LayoutDashboard, Settings, CheckCircle2, XCircle, AlertCircle, RefreshCw } from 'lucide-react';
import { formatCurrency, cn } from '../lib/utils';
import { toast } from 'sonner';

const AdminDashboard: React.FC = () => {
  const { user } = useAuth();
  const [markets, setMarkets] = useState<Market[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [seeding, setSeeding] = useState(false);

  // Form State
  const [formData, setFormData] = useState({
    title: '',
    slug: '',
    summary: '',
    description: '',
    categoryId: '',
    rules: '',
    resolutionSource: '',
    endDate: '',
    image: '',
    initialLiquidity: '1000'
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      const catSnap = await getDocs(collection(db, 'categories'));
      setCategories(catSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Category)));

      const marketSnap = await getDocs(query(collection(db, 'markets'), orderBy('createdAt', 'desc')));
      setMarkets(marketSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Market)));
    } catch (error) {
      toast.error("Failed to fetch admin data");
    } finally {
      setLoading(false);
    }
  };

  const handleCreateMarket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    try {
      const newMarket: Partial<Market> = {
        ...formData,
        status: 'active',
        yesPrice: 0.5,
        noPrice: 0.5,
        volume: 0,
        liquidity: parseFloat(formData.initialLiquidity),
        createdBy: user.id,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        closeDate: formData.endDate,
        resolvedOutcome: null
      };

      await setDoc(doc(db, 'markets', formData.slug), newMarket);
      toast.success("Market created successfully!");
      setShowForm(false);
      fetchData();
    } catch (error) {
      toast.error("Failed to create market");
    }
  };

  const handleResolve = async (marketId: string, outcome: 'YES' | 'NO') => {
    if (!user) return;
    if (!window.confirm(`Are you sure you want to resolve this market to ${outcome}?`)) return;

    try {
      const res = await fetch('/api/admin/resolve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ marketId, outcome, adminId: user.id })
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      
      toast.success(`Market resolved to ${outcome}`);
      fetchData();
    } catch (error: any) {
      toast.error(error.message || "Resolution failed");
    }
  };

  const handleSeed = async () => {
    if (!user) return;
    setSeeding(true);
    try {
      const res = await fetch('/api/admin/seed', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ adminId: user.id })
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      toast.success("Demo data seeded!");
      fetchData();
    } catch (error: any) {
      toast.error(error.message || "Seeding failed");
    } finally {
      setSeeding(false);
    }
  };

  return (
    <div className="space-y-10 pb-20">
      <header className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
        <div>
          <h1 className="text-4xl font-black text-white">Admin Dashboard</h1>
          <p className="text-zinc-500">Manage markets, categories, and users</p>
        </div>
        <div className="flex gap-4">
          <button
            onClick={handleSeed}
            disabled={seeding}
            className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-4 py-2 text-sm font-bold text-white hover:bg-white/10 transition-colors"
          >
            <RefreshCw className={cn("h-4 w-4", seeding && "animate-spin")} />
            Seed Demo Data
          </button>
          <button
            onClick={() => setShowForm(!showForm)}
            className="flex items-center gap-2 rounded-xl bg-orange-500 px-6 py-2 text-sm font-bold text-black transition-transform hover:scale-105 active:scale-95"
          >
            <Plus className="h-4 w-4" />
            Create Market
          </button>
        </div>
      </header>

      {showForm && (
        <section className="rounded-3xl border border-white/10 bg-zinc-900 p-8 shadow-2xl">
          <h2 className="mb-6 text-xl font-bold text-white">New Market</h2>
          <form onSubmit={handleCreateMarket} className="grid gap-6 md:grid-cols-2">
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase text-zinc-500">Title</label>
              <input
                required
                type="text"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="w-full rounded-xl border border-white/10 bg-black p-3 text-sm text-white focus:border-orange-500/50 focus:outline-none"
                placeholder="e.g. Will Bitcoin hit $100k?"
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase text-zinc-500">Slug</label>
              <input
                required
                type="text"
                value={formData.slug}
                onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
                className="w-full rounded-xl border border-white/10 bg-black p-3 text-sm text-white focus:border-orange-500/50 focus:outline-none"
                placeholder="btc-100k"
              />
            </div>
            <div className="space-y-2 md:col-span-2">
              <label className="text-xs font-bold uppercase text-zinc-500">Summary</label>
              <input
                required
                type="text"
                value={formData.summary}
                onChange={(e) => setFormData({ ...formData, summary: e.target.value })}
                className="w-full rounded-xl border border-white/10 bg-black p-3 text-sm text-white focus:border-orange-500/50 focus:outline-none"
                placeholder="Short one-line summary"
              />
            </div>
            <div className="space-y-2 md:col-span-2">
              <label className="text-xs font-bold uppercase text-zinc-500">Description (Markdown)</label>
              <textarea
                required
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="w-full rounded-xl border border-white/10 bg-black p-3 text-sm text-white focus:border-orange-500/50 focus:outline-none"
                rows={4}
                placeholder="Detailed description and context"
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase text-zinc-500">Category</label>
              <select
                required
                value={formData.categoryId}
                onChange={(e) => setFormData({ ...formData, categoryId: e.target.value })}
                className="w-full rounded-xl border border-white/10 bg-black p-3 text-sm text-white focus:border-orange-500/50 focus:outline-none"
              >
                <option value="">Select Category</option>
                {categories.map(c => <option key={c.id} value={c.slug}>{c.name}</option>)}
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase text-zinc-500">End Date</label>
              <input
                required
                type="datetime-local"
                value={formData.endDate}
                onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                className="w-full rounded-xl border border-white/10 bg-black p-3 text-sm text-white focus:border-orange-500/50 focus:outline-none"
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase text-zinc-500">Resolution Source</label>
              <input
                required
                type="text"
                value={formData.resolutionSource}
                onChange={(e) => setFormData({ ...formData, resolutionSource: e.target.value })}
                className="w-full rounded-xl border border-white/10 bg-black p-3 text-sm text-white focus:border-orange-500/50 focus:outline-none"
                placeholder="URL or official source"
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase text-zinc-500">Initial Liquidity</label>
              <input
                required
                type="number"
                value={formData.initialLiquidity}
                onChange={(e) => setFormData({ ...formData, initialLiquidity: e.target.value })}
                className="w-full rounded-xl border border-white/10 bg-black p-3 text-sm text-white focus:border-orange-500/50 focus:outline-none"
              />
            </div>
            <div className="flex justify-end gap-4 md:col-span-2">
              <button
                type="button"
                onClick={() => setShowForm(false)}
                className="rounded-xl px-6 py-2 text-sm font-bold text-zinc-500 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="rounded-xl bg-orange-500 px-8 py-2 text-sm font-bold text-black hover:scale-105 transition-transform"
              >
                Create Market
              </button>
            </div>
          </form>
        </section>
      )}

      {/* Markets List */}
      <section className="space-y-6">
        <div className="flex items-center gap-2">
          <LayoutDashboard className="h-5 w-5 text-orange-500" />
          <h2 className="text-xl font-bold text-white">Manage Markets</h2>
        </div>

        <div className="overflow-hidden rounded-2xl border border-white/10 bg-zinc-900/30">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-white/5 bg-white/5 text-xs font-bold uppercase text-zinc-500">
              <tr>
                <th className="px-6 py-4">Market</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Volume</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {markets.map((m) => (
                <tr key={m.id} className="hover:bg-white/5 transition-colors">
                  <td className="px-6 py-4">
                    <div className="font-bold text-white">{m.title}</div>
                    <div className="text-xs text-zinc-500">{m.slug}</div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={cn(
                      "rounded-full px-2 py-0.5 text-[10px] font-bold uppercase",
                      m.status === 'active' ? "bg-green-500/10 text-green-500" :
                      m.status === 'resolved' ? "bg-blue-500/10 text-blue-500" :
                      "bg-zinc-500/10 text-zinc-500"
                    )}>
                      {m.status}
                    </span>
                    {m.resolvedOutcome && (
                      <span className="ml-2 text-xs font-bold text-white">({m.resolvedOutcome})</span>
                    )}
                  </td>
                  <td className="px-6 py-4 font-mono">{formatCurrency(m.volume)}</td>
                  <td className="px-6 py-4 text-right">
                    {m.status === 'active' && (
                      <div className="flex justify-end gap-2">
                        <button
                          onClick={() => handleResolve(m.id, 'YES')}
                          className="flex items-center gap-1 rounded-lg bg-green-500/10 px-3 py-1 text-xs font-bold text-green-500 hover:bg-green-500 hover:text-black transition-colors"
                        >
                          <CheckCircle2 className="h-3 w-3" />
                          YES
                        </button>
                        <button
                          onClick={() => handleResolve(m.id, 'NO')}
                          className="flex items-center gap-1 rounded-lg bg-red-500/10 px-3 py-1 text-xs font-bold text-red-500 hover:bg-red-500 hover:text-black transition-colors"
                        >
                          <XCircle className="h-3 w-3" />
                          NO
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};

export default AdminDashboard;
