import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  doc, 
  getDoc, 
  collection, 
  query, 
  where, 
  orderBy, 
  limit, 
  onSnapshot, 
  addDoc,
  getDocs
} from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../context/AuthContext';
import { Market, PriceHistory, Comment, Trade, Position } from '../types';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';
import { 
  Clock, 
  Users, 
  TrendingUp, 
  MessageSquare, 
  Info, 
  ArrowUpRight, 
  ArrowDownRight,
  ChevronRight,
  History,
  Activity
} from 'lucide-react';
import { formatCurrency, formatProbability, cn } from '../lib/utils';
import { format, formatDistanceToNow } from 'date-fns';
import { toast } from 'sonner';
import ReactMarkdown from 'react-markdown';

const MarketDetailPage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const { user, login } = useAuth();
  const [market, setMarket] = useState<Market | null>(null);
  const [history, setHistory] = useState<PriceHistory[]>([]);
  const [comments, setComments] = useState<Comment[]>([]);
  const [trades, setTrades] = useState<Trade[]>([]);
  const [position, setPosition] = useState<Position | null>(null);
  const [loading, setLoading] = useState(true);
  const [tradeSide, setTradeSide] = useState<'YES' | 'NO'>('YES');
  const [amount, setAmount] = useState<string>('');
  const [submitting, setSubmitting] = useState(false);
  const [commentBody, setCommentBody] = useState('');

  useEffect(() => {
    if (!slug) return;

    const fetchMarket = async () => {
      const q = query(collection(db, 'markets'), where('slug', '==', slug), limit(1));
      const snap = await getDocs(q);
      if (snap.empty) {
        setLoading(false);
        return;
      }
      const marketData = { id: snap.docs[0].id, ...snap.docs[0].data() } as Market;
      setMarket(marketData);

      // Real-time market updates
      const unsubMarket = onSnapshot(doc(db, 'markets', marketData.id), (docSnap) => {
        if (docSnap.exists()) {
          setMarket({ id: docSnap.id, ...docSnap.data() } as Market);
        }
      });

      // Price History
      const qHistory = query(
        collection(db, 'priceHistory'),
        where('marketId', '==', marketData.id),
        orderBy('timestamp', 'asc')
      );
      const unsubHistory = onSnapshot(qHistory, (snap) => {
        setHistory(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as PriceHistory)));
      });

      // Comments
      const qComments = query(
        collection(db, 'comments'),
        where('marketId', '==', marketData.id),
        orderBy('createdAt', 'desc')
      );
      const unsubComments = onSnapshot(qComments, (snap) => {
        setComments(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Comment)));
      });

      // Recent Trades
      const qTrades = query(
        collection(db, 'trades'),
        where('marketId', '==', marketData.id),
        orderBy('createdAt', 'desc'),
        limit(10)
      );
      const unsubTrades = onSnapshot(qTrades, (snap) => {
        setTrades(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Trade)));
      });

      setLoading(false);
      return () => {
        unsubMarket();
        unsubHistory();
        unsubComments();
        unsubTrades();
      };
    };

    fetchMarket();
  }, [slug]);

  useEffect(() => {
    if (user && market) {
      const positionId = `${user.id}_${market.id}`;
      const unsubPos = onSnapshot(doc(db, 'positions', positionId), (docSnap) => {
        if (docSnap.exists()) {
          setPosition({ id: docSnap.id, ...docSnap.data() } as Position);
        } else {
          setPosition(null);
        }
      });
      return () => unsubPos();
    }
  }, [user, market]);

  const handleTrade = async () => {
    if (!user) {
      login();
      return;
    }
    if (!market || !amount || parseFloat(amount) <= 0) return;
    if (parseFloat(amount) > user.cashBalance) {
      toast.error("Insufficient balance");
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch('/api/trade', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          marketId: market.id,
          side: tradeSide,
          amount: parseFloat(amount)
        })
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      
      toast.success(`Bought ${Math.round(data.shares)} ${tradeSide} shares!`);
      setAmount('');
    } catch (error: any) {
      toast.error(error.message || "Trade failed");
    } finally {
      setSubmitting(false);
    }
  };

  const handleComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !market || !commentBody.trim()) return;

    try {
      await addDoc(collection(db, 'comments'), {
        userId: user.id,
        username: user.username,
        marketId: market.id,
        body: commentBody.trim(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });
      setCommentBody('');
    } catch (error) {
      toast.error("Failed to post comment");
    }
  };

  if (loading) return <div className="flex h-96 items-center justify-center">Loading...</div>;
  if (!market) return <div className="text-center py-20">Market not found</div>;

  const chartData = history.length > 0 ? history : [
    { timestamp: market.createdAt, yesPrice: market.yesPrice, noPrice: market.noPrice },
    { timestamp: new Date().toISOString(), yesPrice: market.yesPrice, noPrice: market.noPrice }
  ];

  const currentPrice = tradeSide === 'YES' ? market.yesPrice : market.noPrice;
  const estShares = amount ? parseFloat(amount) / currentPrice : 0;

  return (
    <div className="grid gap-8 lg:grid-cols-3">
      {/* Left Column: Market Info & Chart */}
      <div className="lg:col-span-2 space-y-8">
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-orange-500">
            <Link to="/markets" className="hover:underline">Markets</Link>
            <ChevronRight className="h-3 w-3 text-zinc-600" />
            <span className="text-zinc-500">{market.categoryId}</span>
          </div>
          <h1 className="text-4xl font-black text-white leading-tight">{market.title}</h1>
          <p className="text-lg text-zinc-400">{market.summary}</p>
        </div>

        {/* Chart */}
        <div className="rounded-3xl border border-white/10 bg-zinc-900/30 p-6">
          <div className="mb-6 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="flex flex-col">
                <span className="text-xs font-bold uppercase text-zinc-500">Probability</span>
                <span className="text-2xl font-black text-white">{formatProbability(market.yesPrice)}</span>
              </div>
              <div className="flex flex-col">
                <span className="text-xs font-bold uppercase text-zinc-500">Volume</span>
                <span className="text-2xl font-black text-white">{formatCurrency(market.volume)}</span>
              </div>
            </div>
            <div className="flex gap-2">
              {['1D', '1W', '1M', 'ALL'].map(t => (
                <button key={t} className="rounded-lg bg-white/5 px-3 py-1 text-xs font-bold text-zinc-400 hover:bg-white/10 hover:text-white transition-colors">
                  {t}
                </button>
              ))}
            </div>
          </div>
          
          <div className="h-[350px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorYes" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#22c55e" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#22c55e" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
                <XAxis 
                  dataKey="timestamp" 
                  hide 
                />
                <YAxis 
                  domain={[0, 1]} 
                  tickFormatter={(val) => `${Math.round(val * 100)}%`}
                  stroke="#ffffff20"
                  fontSize={10}
                />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#18181b', border: '1px solid #ffffff10', borderRadius: '12px' }}
                  labelStyle={{ color: '#71717a', fontSize: '10px' }}
                  itemStyle={{ color: '#22c55e', fontSize: '12px', fontWeight: 'bold' }}
                  labelFormatter={(label) => format(new Date(label), 'MMM d, h:mm a')}
                  formatter={(val: number) => [formatProbability(val), 'Yes Price']}
                />
                <Area 
                  type="monotone" 
                  dataKey="yesPrice" 
                  stroke="#22c55e" 
                  strokeWidth={3}
                  fillOpacity={1} 
                  fill="url(#colorYes)" 
                  animationDuration={1000}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Description & Rules */}
        <div className="space-y-8 rounded-3xl border border-white/10 bg-zinc-900/30 p-8">
          <section className="space-y-4">
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <Info className="h-5 w-5 text-orange-500" />
              About this market
            </h2>
            <div className="prose prose-invert max-w-none text-zinc-400">
              <ReactMarkdown>{market.description}</ReactMarkdown>
            </div>
          </section>

          <div className="h-px bg-white/5" />

          <section className="grid gap-8 sm:grid-cols-2">
            <div className="space-y-2">
              <h3 className="text-sm font-bold uppercase text-zinc-500">Resolution Criteria</h3>
              <p className="text-sm text-zinc-300">{market.rules}</p>
            </div>
            <div className="space-y-2">
              <h3 className="text-sm font-bold uppercase text-zinc-500">Resolution Source</h3>
              <a href={market.resolutionSource} target="_blank" rel="noopener noreferrer" className="text-sm text-orange-500 hover:underline flex items-center gap-1">
                {market.resolutionSource}
                <ArrowUpRight className="h-3 w-3" />
              </a>
            </div>
          </section>
        </div>

        {/* Comments */}
        <section className="space-y-6">
          <h2 className="text-2xl font-bold text-white flex items-center gap-2">
            <MessageSquare className="h-6 w-6 text-orange-500" />
            Discussion
          </h2>
          
          {user ? (
            <form onSubmit={handleComment} className="flex gap-4">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-zinc-800">
                {user.avatar ? <img src={user.avatar} className="h-full w-full rounded-full" referrerPolicy="no-referrer" /> : <Users className="h-5 w-5 text-zinc-500" />}
              </div>
              <div className="flex-1 space-y-2">
                <textarea
                  value={commentBody}
                  onChange={(e) => setCommentBody(e.target.value)}
                  placeholder="What do you think?"
                  className="w-full rounded-2xl border border-white/10 bg-zinc-900/50 p-4 text-sm text-white focus:border-orange-500/50 focus:outline-none"
                  rows={3}
                />
                <div className="flex justify-end">
                  <button
                    disabled={!commentBody.trim()}
                    className="rounded-full bg-orange-500 px-6 py-2 text-sm font-bold text-black disabled:opacity-50"
                  >
                    Post Comment
                  </button>
                </div>
              </div>
            </form>
          ) : (
            <div className="rounded-2xl border border-dashed border-white/10 p-8 text-center">
              <p className="text-zinc-500">Please sign in to join the discussion</p>
              <button onClick={login} className="mt-4 font-bold text-orange-500 hover:underline">Sign In</button>
            </div>
          )}

          <div className="space-y-4">
            {comments.map((comment) => (
              <div key={comment.id} className="flex gap-4 rounded-2xl bg-zinc-900/30 p-4 border border-white/5">
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-zinc-800 text-xs font-bold text-zinc-500">
                  {comment.username[0].toUpperCase()}
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-white">{comment.username}</span>
                    <span className="text-[10px] text-zinc-600 uppercase tracking-wider">
                      {formatDistanceToNow(new Date(comment.createdAt))} ago
                    </span>
                  </div>
                  <p className="text-sm text-zinc-400">{comment.body}</p>
                </div>
              </div>
            ))}
            {comments.length === 0 && <p className="text-center py-10 text-zinc-600 italic">No comments yet. Be the first!</p>}
          </div>
        </section>
      </div>

      {/* Right Column: Trade Panel & Activity */}
      <div className="space-y-8">
        {/* Trade Panel */}
        <div className="sticky top-24 rounded-3xl border border-white/10 bg-zinc-900 p-6 shadow-2xl">
          <div className="mb-6 flex rounded-xl bg-black p-1">
            <button
              onClick={() => setTradeSide('YES')}
              className={cn(
                "flex-1 rounded-lg py-2.5 text-sm font-bold transition-all",
                tradeSide === 'YES' ? "bg-green-500 text-black shadow-lg" : "text-zinc-500 hover:text-white"
              )}
            >
              YES {formatProbability(market.yesPrice)}
            </button>
            <button
              onClick={() => setTradeSide('NO')}
              className={cn(
                "flex-1 rounded-lg py-2.5 text-sm font-bold transition-all",
                tradeSide === 'NO' ? "bg-red-500 text-black shadow-lg" : "text-zinc-500 hover:text-white"
              )}
            >
              NO {formatProbability(market.noPrice)}
            </button>
          </div>

          <div className="space-y-6">
            <div className="space-y-2">
              <div className="flex justify-between text-xs font-bold uppercase text-zinc-500">
                <span>Amount</span>
                {user && <span>Max: {formatCurrency(user.cashBalance)}</span>}
              </div>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 font-bold text-zinc-500">$</span>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full rounded-xl border border-white/10 bg-black py-4 pl-8 pr-4 text-xl font-bold text-white focus:border-orange-500/50 focus:outline-none"
                />
              </div>
            </div>

            <div className="space-y-3 rounded-xl bg-white/5 p-4 text-sm">
              <div className="flex justify-between">
                <span className="text-zinc-500">Avg. Price</span>
                <span className="font-mono font-bold text-white">{formatCurrency(currentPrice)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-500">Est. Shares</span>
                <span className="font-mono font-bold text-white">{estShares.toFixed(2)}</span>
              </div>
              <div className="h-px bg-white/5" />
              <div className="flex justify-between">
                <span className="text-zinc-500">Potential Payout</span>
                <span className="font-mono font-bold text-green-400">{formatCurrency(estShares)}</span>
              </div>
            </div>

            <button
              onClick={handleTrade}
              disabled={submitting || !amount || parseFloat(amount) <= 0 || market.status !== 'active'}
              className={cn(
                "w-full rounded-xl py-4 text-lg font-black transition-all active:scale-95 disabled:opacity-50",
                tradeSide === 'YES' ? "bg-green-500 text-black" : "bg-red-500 text-black"
              )}
            >
              {submitting ? "Processing..." : `Buy ${tradeSide}`}
            </button>

            {market.status !== 'active' && (
              <p className="text-center text-xs font-bold uppercase text-red-500">
                Market is {market.status}
              </p>
            )}
          </div>

          {/* User Position in this market */}
          {position && (
            <div className="mt-8 space-y-4 rounded-2xl border border-white/5 bg-white/5 p-4">
              <h3 className="text-xs font-bold uppercase text-zinc-500 flex items-center gap-2">
                <History className="h-3 w-3" />
                Your Position
              </h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <span className="block text-[10px] text-zinc-500">YES Shares</span>
                  <span className="font-mono font-bold text-white">{position.yesShares.toFixed(2)}</span>
                </div>
                <div>
                  <span className="block text-[10px] text-zinc-500">NO Shares</span>
                  <span className="font-mono font-bold text-white">{position.noShares.toFixed(2)}</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Activity Feed */}
        <div className="rounded-3xl border border-white/10 bg-zinc-900/30 p-6">
          <h3 className="mb-4 text-sm font-bold uppercase text-zinc-500 flex items-center gap-2">
            <Activity className="h-4 w-4 text-orange-500" />
            Recent Activity
          </h3>
          <div className="space-y-4">
            {trades.map((trade) => (
              <div key={trade.id} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <div className={cn(
                    "h-1.5 w-1.5 rounded-full",
                    trade.side === 'YES' ? "bg-green-500" : "bg-red-500"
                  )} />
                  <span className="text-zinc-400">
                    <span className="text-zinc-200 font-medium">User</span> bought {trade.side}
                  </span>
                </div>
                <span className="text-zinc-600">{formatDistanceToNow(new Date(trade.createdAt))} ago</span>
              </div>
            ))}
            {trades.length === 0 && <p className="text-center py-4 text-zinc-600 text-xs italic">No trades yet</p>}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MarketDetailPage;
