import React, { useEffect, useState } from 'react';
import { collection, query, where, getDocs, orderBy, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../context/AuthContext';
import { Link } from 'react-router-dom';
import { Position, Trade, Transaction, Market } from '../types';
import { formatCurrency, formatProbability, cn } from '../lib/utils';
import { motion } from 'motion/react';
import { 
  Wallet, 
  TrendingUp, 
  History, 
  ArrowUpRight, 
  ArrowDownRight,
  PieChart,
  LayoutGrid,
  List
} from 'lucide-react';
import { format } from 'date-fns';

const PortfolioPage: React.FC = () => {
  const { user } = useAuth();
  const [positions, setPositions] = useState<(Position & { market?: Market })[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;

    const fetchPortfolio = async () => {
      setLoading(true);
      try {
        // Fetch Positions
        const qPos = query(collection(db, 'positions'), where('userId', '==', user.id));
        const unsubPos = onSnapshot(qPos, async (snap) => {
          const posList = snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Position));
          
          // Fetch associated markets for each position
          const enrichedPositions = await Promise.all(posList.map(async (pos) => {
            const marketDoc = await getDoc(doc(db, 'markets', pos.marketId));
            return { ...pos, market: marketDoc.exists() ? { id: marketDoc.id, ...marketDoc.data() } as Market : undefined };
          }));
          
          setPositions(enrichedPositions);
        });

        // Fetch Transactions
        const qTrans = query(
          collection(db, 'transactions'), 
          where('userId', '==', user.id),
          orderBy('createdAt', 'desc')
        );
        const unsubTrans = onSnapshot(qTrans, (snap) => {
          setTransactions(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Transaction)));
        });

        setLoading(false);
        return () => {
          unsubPos();
          unsubTrans();
        };
      } catch (error) {
        console.error("Error fetching portfolio:", error);
        setLoading(false);
      }
    };

    fetchPortfolio();
  }, [user]);

  if (!user) return null;

  const activePositions = positions.filter(p => p.market?.status === 'active' && (p.yesShares > 0 || p.noShares > 0));
  const resolvedPositions = positions.filter(p => p.market?.status === 'resolved');

  const totalPortfolioValue = user.cashBalance + activePositions.reduce((acc, p) => {
    const yesValue = p.yesShares * (p.market?.yesPrice || 0);
    const noValue = p.noShares * (p.market?.noPrice || 0);
    return acc + yesValue + noValue;
  }, 0);

  const unrealizedPnL = activePositions.reduce((acc, p) => {
    const yesPnL = p.yesShares * ((p.market?.yesPrice || 0) - p.avgYesEntry);
    const noPnL = p.noShares * ((p.market?.noPrice || 0) - p.avgNoEntry);
    return acc + yesPnL + noPnL;
  }, 0);

  return (
    <div className="space-y-10 pb-20">
      <header className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
        <div>
          <h1 className="text-4xl font-black text-white">Portfolio</h1>
          <p className="text-zinc-500">Track your performance and positions</p>
        </div>
        <div className="flex items-center gap-4 rounded-2xl border border-white/10 bg-zinc-900/50 p-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-orange-500/10 text-orange-500">
            <Wallet className="h-6 w-6" />
          </div>
          <div>
            <span className="text-xs font-bold uppercase text-zinc-500">Available Cash</span>
            <div className="text-2xl font-black text-white">{formatCurrency(user.cashBalance)}</div>
          </div>
        </div>
      </header>

      {/* Stats Grid */}
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-2xl border border-white/10 bg-zinc-900/30 p-6">
          <span className="text-xs font-bold uppercase text-zinc-500">Total Value</span>
          <div className="mt-1 text-2xl font-black text-white">{formatCurrency(totalPortfolioValue)}</div>
        </div>
        <div className="rounded-2xl border border-white/10 bg-zinc-900/30 p-6">
          <span className="text-xs font-bold uppercase text-zinc-500">Unrealized P/L</span>
          <div className={cn(
            "mt-1 text-2xl font-black flex items-center gap-1",
            unrealizedPnL >= 0 ? "text-green-400" : "text-red-400"
          )}>
            {unrealizedPnL >= 0 ? <ArrowUpRight className="h-5 w-5" /> : <ArrowDownRight className="h-5 w-5" />}
            {formatCurrency(Math.abs(unrealizedPnL))}
          </div>
        </div>
        <div className="rounded-2xl border border-white/10 bg-zinc-900/30 p-6">
          <span className="text-xs font-bold uppercase text-zinc-500">Open Positions</span>
          <div className="mt-1 text-2xl font-black text-white">{activePositions.length}</div>
        </div>
        <div className="rounded-2xl border border-white/10 bg-zinc-900/30 p-6">
          <span className="text-xs font-bold uppercase text-zinc-500">Total Trades</span>
          <div className="mt-1 text-2xl font-black text-white">{transactions.filter(t => t.type === 'trade').length}</div>
        </div>
      </div>

      {/* Positions Table */}
      <section className="space-y-6">
        <div className="flex items-center gap-2">
          <LayoutGrid className="h-5 w-5 text-orange-500" />
          <h2 className="text-xl font-bold text-white">Open Positions</h2>
        </div>
        
        <div className="overflow-hidden rounded-2xl border border-white/10 bg-zinc-900/30">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-white/5 bg-white/5 text-xs font-bold uppercase text-zinc-500">
              <tr>
                <th className="px-6 py-4">Market</th>
                <th className="px-6 py-4">Side</th>
                <th className="px-6 py-4">Shares</th>
                <th className="px-6 py-4">Avg. Entry</th>
                <th className="px-6 py-4">Current Price</th>
                <th className="px-6 py-4 text-right">Value</th>
                <th className="px-6 py-4 text-right">P/L</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {activePositions.map((pos) => {
                const side = pos.yesShares > 0 ? 'YES' : 'NO';
                const shares = side === 'YES' ? pos.yesShares : pos.noShares;
                const avgEntry = side === 'YES' ? pos.avgYesEntry : pos.avgNoEntry;
                const currentPrice = side === 'YES' ? (pos.market?.yesPrice || 0) : (pos.market?.noPrice || 0);
                const value = shares * currentPrice;
                const pnl = shares * (currentPrice - avgEntry);

                return (
                  <tr key={pos.id} className="group hover:bg-white/5 transition-colors">
                    <td className="px-6 py-4">
                      <Link to={`/markets/${pos.market?.slug}`} className="font-bold text-white hover:text-orange-500">
                        {pos.market?.title}
                      </Link>
                    </td>
                    <td className="px-6 py-4">
                      <span className={cn(
                        "rounded-full px-2 py-0.5 text-[10px] font-bold uppercase",
                        side === 'YES' ? "bg-green-500/10 text-green-500" : "bg-red-500/10 text-red-500"
                      )}>
                        {side}
                      </span>
                    </td>
                    <td className="px-6 py-4 font-mono">{shares.toFixed(2)}</td>
                    <td className="px-6 py-4 font-mono">{formatCurrency(avgEntry)}</td>
                    <td className="px-6 py-4 font-mono">{formatCurrency(currentPrice)}</td>
                    <td className="px-6 py-4 text-right font-mono font-bold">{formatCurrency(value)}</td>
                    <td className={cn(
                      "px-6 py-4 text-right font-mono font-bold",
                      pnl >= 0 ? "text-green-400" : "text-red-400"
                    )}>
                      {pnl >= 0 ? '+' : ''}{formatCurrency(pnl)}
                    </td>
                  </tr>
                );
              })}
              {activePositions.length === 0 && (
                <tr>
                  <td colSpan={7} className="px-6 py-20 text-center text-zinc-600 italic">
                    No active positions. Start trading to see them here!
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      {/* Transaction History */}
      <section className="space-y-6">
        <div className="flex items-center gap-2">
          <History className="h-5 w-5 text-orange-500" />
          <h2 className="text-xl font-bold text-white">Recent Transactions</h2>
        </div>
        
        <div className="overflow-hidden rounded-2xl border border-white/10 bg-zinc-900/30">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-white/5 bg-white/5 text-xs font-bold uppercase text-zinc-500">
              <tr>
                <th className="px-6 py-4">Date</th>
                <th className="px-6 py-4">Type</th>
                <th className="px-6 py-4">Amount</th>
                <th className="px-6 py-4">Balance After</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {transactions.slice(0, 10).map((t) => (
                <tr key={t.id} className="hover:bg-white/5 transition-colors">
                  <td className="px-6 py-4 text-zinc-400">
                    {format(new Date(t.createdAt), 'MMM d, yyyy HH:mm')}
                  </td>
                  <td className="px-6 py-4">
                    <span className="font-bold uppercase tracking-wider text-xs">{t.type}</span>
                  </td>
                  <td className={cn(
                    "px-6 py-4 font-mono font-bold",
                    t.amount >= 0 ? "text-green-400" : "text-red-400"
                  )}>
                    {t.amount >= 0 ? '+' : ''}{formatCurrency(t.amount)}
                  </td>
                  <td className="px-6 py-4 font-mono text-zinc-300">
                    {formatCurrency(t.balanceAfter)}
                  </td>
                </tr>
              ))}
              {transactions.length === 0 && (
                <tr>
                  <td colSpan={4} className="px-6 py-10 text-center text-zinc-600 italic">
                    No transactions yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};

export default PortfolioPage;

import { doc, getDoc } from 'firebase/firestore';
